A bunch of methods to describe datasets as completely as possible.


A good starting point it so implement metafeatures described in Alexandros Kalousis's thesis "Algorithm Selection via Meta-Learning" and other relevant works.



