{
 "default-label": { 
    "description": "Default Label",
    "type": "enum-radio",
    "values": [0, 1],
    "default": 0
 },
 "tie-break": { 
    "description": "Tie Break",
    "type": "enum-radio",
    "values": [0, 1],
    "default": 1
 }
}
