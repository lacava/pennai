# dis

## Summary Stats

#instances: 3772

#features: 29

  #binary_features: 21

  #integer_features: 8

  #float_features: 0

Endpoint type: binary

#Classes: 2

Imbalance metric: 0.9394399094067016

## Feature Types

 age:discrete

sex:discrete

on thyroxine:binary

query on thyroxine:binary

on antithyroid medication:binary

sick:binary

pregnant:binary

thyroid surgery:binary

I131 treatment:binary

query hypothyroid:binary

query hyperthyroid:binary

lithium:binary

goitre:binary

tumor:binary

hypopituitary:binary

psych:binary

TSH measured:binary

TSH:discrete

T3 measured:binary

T3:discrete

TT4 measured:binary

TT4:discrete

T4U measured:binary

T4U:discrete

FTI measured:binary

FTI:discrete

TBG measured:binary

TBG:binary

referral source:discrete

