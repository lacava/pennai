# cleveland-nominal

## Summary Stats

#instances: 303

#features: 7

  #binary_features: 3

  #integer_features: 4

  #float_features: 0

Endpoint type: integer

#Classes: 5

Imbalance metric: 0.19400603426679297

## Feature Types

 sex:binary

cp:discrete

fbs:binary

restecg:discrete

exang:binary

slope:discrete

thal:discrete

