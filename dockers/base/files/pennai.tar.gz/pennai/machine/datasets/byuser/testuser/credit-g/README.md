# credit-g

## Summary Stats

#instances: 1000

#features: 20

  #binary_features: 2

  #integer_features: 11

  #float_features: 7

Endpoint type: binary

#Classes: 2

Imbalance metric: 0.15999999999999998

## Feature Types

 checking_status:discrete

duration:continous

credit_history:discrete

purpose:discrete

credit_amount:continous

savings_status:discrete

employment:discrete

installment_commitment:continous

personal_status:discrete

other_parties:discrete

residence_since:continous

property_magnitude:discrete

age:continous

other_payment_plans:discrete

housing:discrete

existing_credits:continous

job:discrete

num_dependents:continous

own_telephone:binary

foreign_worker:binary

