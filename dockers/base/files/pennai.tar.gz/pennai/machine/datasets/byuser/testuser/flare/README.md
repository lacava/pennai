# flare

## Summary Stats

#instances: 1066

#features: 10

  #binary_features: 1

  #integer_features: 7

  #float_features: 2

Endpoint type: binary

#Classes: 2

Imbalance metric: 0.43367043426531815

## Feature Types

 class code:discrete

largest spot code:discrete

spot dist code:discrete

Activity:binary

Evolution:continous

Previous 24 hour code:continous

Historically-complex:binary

become complex:binary

Area:binary

Area of the largest spot:binary

