# mfeat-zernike

## Summary Stats

#instances: 2000

#features: 47

  #binary_features: 0

  #integer_features: 0

  #float_features: 47

Endpoint type: integer

#Classes: 10

Imbalance metric: 0.0

## Feature Types

 att1:continous

att2:continous

att3:continous

att4:continous

att5:continous

att6:continous

att7:continous

att8:continous

att9:continous

att10:continous

att11:continous

att12:continous

att13:continous

att14:continous

att15:continous

att16:continous

att17:continous

att18:continous

att19:continous

att20:continous

att21:continous

att22:continous

att23:continous

att24:continous

att25:continous

att26:continous

att27:continous

att28:continous

att29:continous

att30:continous

att31:continous

att32:continous

att33:continous

att34:continous

att35:continous

att36:continous

att37:continous

att38:continous

att39:continous

att40:continous

att41:continous

att42:continous

att43:continous

att44:continous

att45:continous

att46:continous

att47:continous

