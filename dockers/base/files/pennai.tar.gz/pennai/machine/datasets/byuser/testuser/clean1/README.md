# clean1

## Summary Stats

#instances: 476

#features: 168

  #binary_features: 0

  #integer_features: 2

  #float_features: 166

Endpoint type: binary

#Classes: 2

Imbalance metric: 0.016965609773321087

## Feature Types

 molecule_name:discrete

conformation_name:discrete

f1:continous

f2:continous

f3:continous

f4:continous

f5:continous

f6:continous

f7:continous

f8:continous

f9:continous

f10:continous

f11:continous

f12:continous

f13:continous

f14:continous

f15:continous

f16:continous

f17:continous

f18:continous

f19:continous

f20:continous

f21:continous

f22:continous

f23:continous

f24:continous

f25:continous

f26:continous

f27:continous

f28:continous

f29:continous

f30:continous

f31:continous

f32:continous

f33:continous

f34:continous

f35:continous

f36:continous

f37:continous

f38:continous

f39:continous

f40:continous

f41:continous

f42:continous

f43:continous

f44:continous

f45:continous

f46:continous

f47:continous

f48:continous

f49:continous

f50:continous

f51:continous

f52:continous

f53:continous

f54:continous

f55:continous

f56:continous

f57:continous

f58:continous

f59:continous

f60:continous

f61:continous

f62:continous

f63:continous

f64:continous

f65:continous

f66:continous

f67:continous

f68:continous

f69:continous

f70:continous

f71:continous

f72:continous

f73:continous

f74:continous

f75:continous

f76:continous

f77:continous

f78:continous

f79:continous

f80:continous

f81:continous

f82:continous

f83:continous

f84:continous

f85:continous

f86:continous

f87:continous

f88:continous

f89:continous

f90:continous

f91:continous

f92:continous

f93:continous

f94:continous

f95:continous

f96:continous

f97:continous

f98:continous

f99:continous

f100:continous

f101:continous

f102:continous

f103:continous

f104:continous

f105:continous

f106:continous

f107:continous

f108:continous

f109:continous

f110:continous

f111:continous

f112:continous

f113:continous

f114:continous

f115:continous

f116:continous

f117:continous

f118:continous

f119:continous

f120:continous

f121:continous

f122:continous

f123:continous

f124:continous

f125:continous

f126:continous

f127:continous

f128:continous

f129:continous

f130:continous

f131:continous

f132:continous

f133:continous

f134:continous

f135:continous

f136:continous

f137:continous

f138:continous

f139:continous

f140:continous

f141:continous

f142:continous

f143:continous

f144:continous

f145:continous

f146:continous

f147:continous

f148:continous

f149:continous

f150:continous

f151:continous

f152:continous

f153:continous

f154:continous

f155:continous

f156:continous

f157:continous

f158:continous

f159:continous

f160:continous

f161:continous

f162:continous

f163:continous

f164:continous

f165:continous

f166:continous

