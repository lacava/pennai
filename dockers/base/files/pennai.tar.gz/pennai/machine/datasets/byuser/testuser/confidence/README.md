# confidence

## Summary Stats

#instances: 72

#features: 3

  #binary_features: 0

  #integer_features: 0

  #float_features: 3

Endpoint type: integer

#Classes: 6

Imbalance metric: 0.0

## Feature Types

 P:continous

N:continous

O:continous

