# Benchmark data sets

This directory contains over 150 data sets for benchmarking supervised machine learning algorithms.

Each subdirectory corresponds to a separate data set, and will have a README file providing some basic information about the data set.

# High-level summary of data sets

[in progress]
