# horse-colic

## Summary Stats

#instances: 368

#features: 22

  #binary_features: 0

  #integer_features: 22

  #float_features: 0

Endpoint type: binary

#Classes: 2

Imbalance metric: 0.0680529300567108

## Feature Types

 surgery:discrete

Age:binary

rectal temperature:discrete

pulse:discrete

respiratory rate:discrete

temperature of extremities:discrete

peripheral pulse:discrete

mucous membranes:discrete

capillary refill time:discrete

pain:discrete

peristalsis:discrete

abdominal distension:discrete

nasogastric tube:discrete

nasogastric reflux:discrete

nasogastric reflux PH:discrete

rectal examination:discrete

abdomen:discrete

packed cell volume:discrete

total protein:discrete

abdominocentesis appearance:discrete

abdomcentesis total protein:discrete

outcome:discrete

