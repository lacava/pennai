# wine-quality-red

## Summary Stats

#instances: 1599

#features: 11

  #binary_features: 0

  #integer_features: 0

  #float_features: 11

Endpoint type: integer

#Classes: 6

Imbalance metric: 0.22880411889701233

## Feature Types

 fixed acidity:continous

volatile acidity:continous

citric acid:continous

residual sugar:continous

chlorides:continous

free sulfur dioxide:continous

total sulfur dioxide:continous

density:continous

pH:continous

sulphates:continous

alcohol:continous

