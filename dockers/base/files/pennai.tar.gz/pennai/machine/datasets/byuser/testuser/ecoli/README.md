# ecoli

## Summary Stats

#instances: 327

#features: 7

  #binary_features: 0

  #integer_features: 0

  #float_features: 7

Endpoint type: integer

#Classes: 5

Imbalance metric: 0.10896482712828137

## Feature Types

 mcg:continous

gvh:continous

lip:continous

chg:continous

aac:continous

alm1:continous

alm2:continous

