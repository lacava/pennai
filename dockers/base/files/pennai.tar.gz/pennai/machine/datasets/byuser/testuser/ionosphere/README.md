# ionosphere

## Summary Stats

#instances: 351

#features: 34

  #binary_features: 2

  #integer_features: 0

  #float_features: 32

Endpoint type: binary

#Classes: 2

Imbalance metric: 0.07955292570677189

## Feature Types

 0:binary

1:binary

2:continous

3:continous

4:continous

5:continous

6:continous

7:continous

8:continous

9:continous

10:continous

11:continous

12:continous

13:continous

14:continous

15:continous

16:continous

17:continous

18:continous

19:continous

20:continous

21:continous

22:continous

23:continous

24:continous

25:continous

26:continous

27:continous

28:continous

29:continous

30:continous

31:continous

32:continous

33:continous

