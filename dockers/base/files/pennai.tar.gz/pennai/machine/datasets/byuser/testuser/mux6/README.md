# mux6

## Summary Stats

#instances: 128

#features: 6

  #binary_features: 6

  #integer_features: 0

  #float_features: 0

Endpoint type: binary

#Classes: 2

Imbalance metric: 0.0

## Feature Types

 Address bit 1:binary

Address bit 2:binary

Bit 0:binary

Bit 1:binary

Bit 2:binary

Bit 3:binary

