# cars

## Summary Stats

#instances: 392

#features: 8

  #binary_features: 0

  #integer_features: 1

  #float_features: 7

Endpoint type: integer

#Classes: 3

Imbalance metric: 0.1919968242399

## Feature Types

 MPG:continous

cylinders:continous

cubicInches:continous

horsepower:continous

weightLbs:continous

time-to-sixty:continous

year:continous

brand:discrete

