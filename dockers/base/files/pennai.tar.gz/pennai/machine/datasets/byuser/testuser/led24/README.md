# led24

## Summary Stats

#instances: 3200

#features: 24

  #binary_features: 24

  #integer_features: 0

  #float_features: 0

Endpoint type: integer

#Classes: 10

Imbalance metric: 0.0001885850694444445

## Feature Types

 attribute#1:binary

attribute#2:binary

attribute#3:binary

attribute#4:binary

attribute#5:binary

attribute#6:binary

attribute#7:binary

irrelevant1:binary

irrelevant2:binary

irrelevant3:binary

irrelevant4:binary

irrelevant5:binary

irrelevant6:binary

irrelevant7:binary

irrelevant8:binary

irrelevant9:binary

irrelevant10:binary

irrelevant11:binary

irrelevant12:binary

irrelevant13:binary

irrelevant14:binary

irrelevant15:binary

irrelevant16:binary

irrelevant17:binary

