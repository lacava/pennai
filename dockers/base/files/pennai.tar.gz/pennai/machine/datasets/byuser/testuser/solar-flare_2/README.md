# solar-flare_2

## Summary Stats

#instances: 1066

#features: 12

  #binary_features: 1

  #integer_features: 11

  #float_features: 0

Endpoint type: integer

#Classes: 6

Imbalance metric: 0.057334145285456294

## Feature Types

 largest_spot_size:discrete

spot_distribution:discrete

Activity:binary

Evolution:discrete

Previous_24_hour_flare_activity_code:discrete

Historically-complex:binary

Did_region_become_historically_complex:binary

Area:binary

Area_of_the_largest_spot:binary

C-class_flares_production_by_this_region:discrete

M-class_flares_production_by_this_region:discrete

X-class_flares_production_by_this_region:discrete

