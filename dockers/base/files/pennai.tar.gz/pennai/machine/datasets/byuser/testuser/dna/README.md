# dna

## Summary Stats

#instances: 3186

#features: 180

  #binary_features: 180

  #integer_features: 0

  #float_features: 0

Endpoint type: integer

#Classes: 3

Imbalance metric: 0.07768479801580122

## Feature Types

 A0:binary

A1:binary

A2:binary

A3:binary

A4:binary

A5:binary

A6:binary

A7:binary

A8:binary

A9:binary

A10:binary

A11:binary

A12:binary

A13:binary

A14:binary

A15:binary

A16:binary

A17:binary

A18:binary

A19:binary

A20:binary

A21:binary

A22:binary

A23:binary

A24:binary

A25:binary

A26:binary

A27:binary

A28:binary

A29:binary

A30:binary

A31:binary

A32:binary

A33:binary

A34:binary

A35:binary

A36:binary

A37:binary

A38:binary

A39:binary

A40:binary

A41:binary

A42:binary

A43:binary

A44:binary

A45:binary

A46:binary

A47:binary

A48:binary

A49:binary

A50:binary

A51:binary

A52:binary

A53:binary

A54:binary

A55:binary

A56:binary

A57:binary

A58:binary

A59:binary

A60:binary

A61:binary

A62:binary

A63:binary

A64:binary

A65:binary

A66:binary

A67:binary

A68:binary

A69:binary

A70:binary

A71:binary

A72:binary

A73:binary

A74:binary

A75:binary

A76:binary

A77:binary

A78:binary

A79:binary

A80:binary

A81:binary

A82:binary

A83:binary

A84:binary

A85:binary

A86:binary

A87:binary

A88:binary

A89:binary

A90:binary

A91:binary

A92:binary

A93:binary

A94:binary

A95:binary

A96:binary

A97:binary

A98:binary

A99:binary

A100:binary

A101:binary

A102:binary

A103:binary

A104:binary

A105:binary

A106:binary

A107:binary

A108:binary

A109:binary

A110:binary

A111:binary

A112:binary

A113:binary

A114:binary

A115:binary

A116:binary

A117:binary

A118:binary

A119:binary

A120:binary

A121:binary

A122:binary

A123:binary

A124:binary

A125:binary

A126:binary

A127:binary

A128:binary

A129:binary

A130:binary

A131:binary

A132:binary

A133:binary

A134:binary

A135:binary

A136:binary

A137:binary

A138:binary

A139:binary

A140:binary

A141:binary

A142:binary

A143:binary

A144:binary

A145:binary

A146:binary

A147:binary

A148:binary

A149:binary

A150:binary

A151:binary

A152:binary

A153:binary

A154:binary

A155:binary

A156:binary

A157:binary

A158:binary

A159:binary

A160:binary

A161:binary

A162:binary

A163:binary

A164:binary

A165:binary

A166:binary

A167:binary

A168:binary

A169:binary

A170:binary

A171:binary

A172:binary

A173:binary

A174:binary

A175:binary

A176:binary

A177:binary

A178:binary

A179:binary

