# yeast

## Summary Stats

#instances: 1479

#features: 8

  #binary_features: 0

  #integer_features: 0

  #float_features: 8

Endpoint type: integer

#Classes: 9

Imbalance metric: 0.1278178474299421

## Feature Types

 mcg:continous

gvh:continous

alm:continous

mit:continous

erl:continous

pox:continous

vac:continous

nuc:continous

