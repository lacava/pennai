# labor

## Summary Stats

#instances: 57

#features: 16

  #binary_features: 0

  #integer_features: 16

  #float_features: 0

Endpoint type: binary

#Classes: 2

Imbalance metric: 0.08895044629116654

## Feature Types

 duration:discrete

wage increase first year:discrete

wage increase second year:discrete

wage increase third year:discrete

cost of living adjustment:discrete

working hours:discrete

pension:discrete

standby pay:discrete

shift differential:discrete

education allowance:discrete

statutory holidays:discrete

vacation:discrete

longterm disability assistance:discrete

contribution to dental plan:discrete

bereavement assistance:discrete

contribution to health plan:discrete

