# auto

## Summary Stats

#instances: 202

#features: 25

  #binary_features: 3

  #integer_features: 13

  #float_features: 9

Endpoint type: integer

#Classes: 5

Imbalance metric: 0.045375453386922844

## Feature Types

 normalized-losses:discrete

make:discrete

fuel-type:binary

aspiration:binary

num-of-doors:discrete

body-style:discrete

drive-wheels:discrete

engine-location:binary

wheel-base:continous

length:continous

width:continous

height:continous

curb-weight:continous

engine-type:discrete

num-of-cylinders:discrete

engine-size:continous

fuel-system:discrete

bore:discrete

stroke:discrete

compression-ratio:continous

horsepower:discrete

peak-rpm:discrete

city-mpg:continous

highway-mpg:continous

price:discrete

