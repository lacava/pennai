# breast-cancer

## Summary Stats

#instances: 286

#features: 9

  #binary_features: 2

  #integer_features: 7

  #float_features: 0

Endpoint type: binary

#Classes: 2

Imbalance metric: 0.1645068218494792

## Feature Types

 age:discrete

menopause:discrete

tumor-size:discrete

inv-nodes:discrete

node-caps:discrete

deg-malig:discrete

breast:binary

breast-quad:discrete

irradiat:binary

