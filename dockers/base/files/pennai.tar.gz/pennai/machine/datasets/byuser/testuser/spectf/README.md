# spectf

## Summary Stats

#instances: 349

#features: 44

  #binary_features: 0

  #integer_features: 0

  #float_features: 44

Endpoint type: binary

#Classes: 2

Imbalance metric: 0.20755987225063832

## Feature Types

 F1R:continous

F1S:continous

F2R:continous

F2S:continous

F3R:continous

F3S:continous

F4R:continous

F4S:continous

F5R:continous

F5S:continous

F6R:continous

F6S:continous

F7R:continous

F7S:continous

F8R:continous

F8S:continous

F9R:continous

F9S:continous

F10R:continous

F10S:continous

F11R:continous

F11S:continous

F12R:continous

F12S:continous

F13R:continous

F13S:continous

F14R:continous

F14S:continous

F15R:continous

F15S:continous

F16R:continous

F16S:continous

F17R:continous

F17S:continous

F18R:continous

F18S:continous

F19R:continous

F19S:continous

F20R:continous

F20S:continous

F21R:continous

F21S:continous

F22R:continous

F22S:continous

