# adult

## Summary Stats

#instances: 48842

#features: 14

  #binary_features: 1

  #integer_features: 7

  #float_features: 6

Endpoint type: binary

#Classes: 2

Imbalance metric: 0.27189599079967847

## Feature Types

 age:continous

workclass:discrete

fnlwgt:continous

education:discrete

education-num:continous

marital-status:discrete

occupation:discrete

relationship:discrete

race:discrete

sex:binary

capital-gain:continous

capital-loss:continous

hours-per-week:continous

native-country:discrete

