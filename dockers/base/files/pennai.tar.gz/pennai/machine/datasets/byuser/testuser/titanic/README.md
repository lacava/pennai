# titanic

## Summary Stats

#instances: 2201

#features: 3

  #binary_features: 0

  #integer_features: 0

  #float_features: 3

Endpoint type: binary

#Classes: 2

Imbalance metric: 0.12526646741258618

## Feature Types

 Class:continous

Age:continous

Sex:continous

