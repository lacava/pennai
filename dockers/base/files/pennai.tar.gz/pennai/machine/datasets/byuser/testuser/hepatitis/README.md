# hepatitis

## Summary Stats

#instances: 155

#features: 19

  #binary_features: 0

  #integer_features: 18

  #float_features: 1

Endpoint type: binary

#Classes: 2

Imbalance metric: 0.3446826222684704

## Feature Types

 AGE:continous

SEX:binary

STEROID:discrete

ANTIVIRALS:binary

FATIGUE:discrete

MALAISE:discrete

ANOREXIA:discrete

LIVER BIG:discrete

LIVER FIRM:discrete

SPLEEN PALPABLE:discrete

SPIDERS:discrete

ASCITES:discrete

VARICES:discrete

BILIRUBIN:discrete

ALK PHOSPHATE:discrete

SGOT:discrete

ALBUMIN:discrete

PROTIME:discrete

HISTOLOGY:binary

