# churn

## Summary Stats

#instances: 5000

#features: 20

  #binary_features: 2

  #integer_features: 2

  #float_features: 16

Endpoint type: binary

#Classes: 2

Imbalance metric: 0.5143758400000001

## Feature Types

 state:discrete

account length:continous

area code:continous

phone number:discrete

international plan:binary

voice mail plan:binary

number vmail messages:continous

total day minutes:continous

total day calls:continous

total day charge:continous

total eve minutes:continous

total eve calls:continous

total eve charge:continous

total night minutes:continous

total night calls:continous

total night charge:continous

total intl minutes:continous

total intl calls:continous

total intl charge:continous

number customer service calls:continous

