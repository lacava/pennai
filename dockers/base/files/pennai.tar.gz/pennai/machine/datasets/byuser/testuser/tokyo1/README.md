# tokyo1

## Summary Stats

#instances: 959

#features: 44

  #binary_features: 0

  #integer_features: 0

  #float_features: 44

Endpoint type: binary

#Classes: 2

Imbalance metric: 0.07751492093454143

## Feature Types

 cpu_avg_user:continous

cpu_avg_sys:continous

cpu_avg_busy:continous

cpu_avg_wait:continous

cpu_avg_idle:continous

cpu_avg_waste:continous

cpu_max_user:continous

cpu_max_sys:continous

cpu_max_busy:continous

cpu_max_wait:continous

cpu_max_idle:continous

cpu_max_waste:continous

cpu_frac_busy:continous

io_iget:continous

io_bread:continous

io_bwrite:continous

io_lread:continous

io_lwrite:continous

io_phread:continous

io_phwrite:continous

io_wcancel:continous

io_namei:continous

io_dirblk:continous

disk_avg_active:continous

disk_max_active:continous

disk_frac_active:continous

disk_avg_read:continous

disk_avg_write:continous

disk_avg_total:continous

disk_max_read:continous

disk_max_write:continous

disk_max_total:continous

disk_frac_busy:continous

net_avg_read:continous

net_avg_write:continous

net_avg_total:continous

net_max_read:continous

net_max_write:continous

net_max_total:continous

net_frac_busy:continous

mem_swap:continous

mem_fault:continous

mem_tlbflush:continous

syscall_total:continous

