# prnn_synth

## Summary Stats

#instances: 250

#features: 2

  #binary_features: 0

  #integer_features: 0

  #float_features: 2

Endpoint type: binary

#Classes: 2

Imbalance metric: 0.0

## Feature Types

 xs:continous

ys:continous

