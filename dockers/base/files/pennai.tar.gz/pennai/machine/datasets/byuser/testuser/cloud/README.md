# cloud

## Summary Stats

#instances: 108

#features: 7

  #binary_features: 1

  #integer_features: 0

  #float_features: 6

Endpoint type: integer

#Classes: 4

Imbalance metric: 0.005029721079103795

## Feature Types

 PERIOD:continous

SEEDED:binary

TE:continous

TW:continous

NC:continous

SC:continous

NWC:continous

