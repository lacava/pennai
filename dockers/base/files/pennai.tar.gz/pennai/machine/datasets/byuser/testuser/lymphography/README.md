# lymphography

## Summary Stats

#instances: 148

#features: 18

  #binary_features: 9

  #integer_features: 9

  #float_features: 0

Endpoint type: integer

#Classes: 4

Imbalance metric: 0.29376673971268563

## Feature Types

 Lymphatics:discrete

Block_of_affere:binary

Bl_of_lymph_c:binary

Bl_of_lymph_s:binary

By_pass:binary

Extravasates:binary

Regeneration_of:binary

Early_uptake_in:binary

Lym_nodes_dimin:discrete

Lym_nodes_enlar:discrete

Changes_in_lym:discrete

Defect_in_node:discrete

Changes_in_node:discrete

Changes_in_stru:discrete

Special_forms:discrete

Dislocation_of:binary

Exclusion_of_no:binary

No_of_nodes_in:discrete

