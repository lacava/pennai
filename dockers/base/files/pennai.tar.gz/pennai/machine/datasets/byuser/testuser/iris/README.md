# iris

## Summary Stats

#instances: 150

#features: 4

  #binary_features: 0

  #integer_features: 0

  #float_features: 4

Endpoint type: integer

#Classes: 3

Imbalance metric: 0.0

## Feature Types

 sepal-length:continous

sepal-width:continous

petal-length:continous

petal-width:continous

