# glass2

## Summary Stats

#instances: 163

#features: 9

  #binary_features: 0

  #integer_features: 0

  #float_features: 9

Endpoint type: binary

#Classes: 2

Imbalance metric: 0.004554179683089322

## Feature Types

 Refractive Index:continous

Sodium:continous

Magnesium:continous

Aluminum:continous

Silicon:continous

Potassium:continous

Calcium:continous

Barium:continous

Iron:continous

