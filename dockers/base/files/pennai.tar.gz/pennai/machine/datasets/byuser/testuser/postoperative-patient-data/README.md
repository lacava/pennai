# postoperative-patient-data

## Summary Stats

#instances: 88

#features: 8

  #binary_features: 2

  #integer_features: 6

  #float_features: 0

Endpoint type: binary

#Classes: 2

Imbalance metric: 0.20661157024793392

## Feature Types

 L-CORE:discrete

L-SURF:discrete

L-O2:binary

L-BP:discrete

SURF-STBL:binary

CORE-STBL:discrete

BP-STBL:discrete

COMFORT:discrete

