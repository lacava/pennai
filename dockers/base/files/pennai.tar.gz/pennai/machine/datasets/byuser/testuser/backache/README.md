# backache

## Summary Stats

#instances: 180

#features: 32

  #binary_features: 22

  #integer_features: 4

  #float_features: 6

Endpoint type: binary

#Classes: 2

Imbalance metric: 0.521604938271605

## Feature Types

 id:continous

col_2:discrete

col_3:discrete

col_4:continous

col_5:continous

col_6:continous

col_7:continous

col_8:continous

col_9:discrete

col_10:discrete

col_11:binary

col_12:binary

col_13:binary

col_14:binary

col_15:binary

col_16:binary

col_17:binary

col_18:binary

col_19:binary

col_20:binary

col_21:binary

col_22:binary

col_23:binary

col_24:binary

col_25:binary

col_26:binary

col_27:binary

col_28:binary

col_29:binary

col_30:binary

col_31:binary

col_32:binary

