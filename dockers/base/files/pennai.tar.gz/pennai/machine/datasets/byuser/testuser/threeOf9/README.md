# threeOf9

## Summary Stats

#instances: 512

#features: 9

  #binary_features: 9

  #integer_features: 0

  #float_features: 0

Endpoint type: binary

#Classes: 2

Imbalance metric: 0.00494384765625

## Feature Types

 F1:binary

F2:binary

F3:binary

F4:binary

F5:binary

F6:binary

F7:binary

F8:binary

F9:binary

