# calendarDOW

## Summary Stats

#instances: 399

#features: 32

  #binary_features: 2

  #integer_features: 30

  #float_features: 0

Endpoint type: integer

#Classes: 5

Imbalance metric: 0.014029434488476825

## Feature Types

 Feature00:discrete

Feature01:discrete

Feature02:discrete

Feature03:discrete

Feature04:discrete

Feature05:discrete

Feature06:discrete

Feature07:discrete

Feature08:discrete

Feature09:discrete

Feature10:discrete

Feature11:discrete

Feature12:discrete

Feature13:discrete

Feature14:discrete

Feature15:discrete

Feature16:discrete

Feature17:discrete

Feature18:discrete

Feature19:discrete

Feature20:discrete

Feature21:discrete

Feature22:discrete

Feature23:discrete

Feature24:binary

Feature25:binary

Feature26:discrete

Feature27:discrete

Feature28:discrete

Feature29:discrete

Feature30:discrete

Feature31:discrete

