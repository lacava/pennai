# mfeat-factors

## Summary Stats

#instances: 2000

#features: 216

  #binary_features: 0

  #integer_features: 0

  #float_features: 216

Endpoint type: integer

#Classes: 10

Imbalance metric: 0.0

## Feature Types

 att1:continous

att2:continous

att3:continous

att4:continous

att5:continous

att6:continous

att7:continous

att8:continous

att9:continous

att10:continous

att11:continous

att12:continous

att13:continous

att14:continous

att15:continous

att16:continous

att17:continous

att18:continous

att19:continous

att20:continous

att21:continous

att22:continous

att23:continous

att24:continous

att25:continous

att26:continous

att27:continous

att28:continous

att29:continous

att30:continous

att31:continous

att32:continous

att33:continous

att34:continous

att35:continous

att36:continous

att37:continous

att38:continous

att39:continous

att40:continous

att41:continous

att42:continous

att43:continous

att44:continous

att45:continous

att46:continous

att47:continous

att48:continous

att49:continous

att50:continous

att51:continous

att52:continous

att53:continous

att54:continous

att55:continous

att56:continous

att57:continous

att58:continous

att59:continous

att60:continous

att61:continous

att62:continous

att63:continous

att64:continous

att65:continous

att66:continous

att67:continous

att68:continous

att69:continous

att70:continous

att71:continous

att72:continous

att73:continous

att74:continous

att75:continous

att76:continous

att77:continous

att78:continous

att79:continous

att80:continous

att81:continous

att82:continous

att83:continous

att84:continous

att85:continous

att86:continous

att87:continous

att88:continous

att89:continous

att90:continous

att91:continous

att92:continous

att93:continous

att94:continous

att95:continous

att96:continous

att97:continous

att98:continous

att99:continous

att100:continous

att101:continous

att102:continous

att103:continous

att104:continous

att105:continous

att106:continous

att107:continous

att108:continous

att109:continous

att110:continous

att111:continous

att112:continous

att113:continous

att114:continous

att115:continous

att116:continous

att117:continous

att118:continous

att119:continous

att120:continous

att121:continous

att122:continous

att123:continous

att124:continous

att125:continous

att126:continous

att127:continous

att128:continous

att129:continous

att130:continous

att131:continous

att132:continous

att133:continous

att134:continous

att135:continous

att136:continous

att137:continous

att138:continous

att139:continous

att140:continous

att141:continous

att142:continous

att143:continous

att144:continous

att145:continous

att146:continous

att147:continous

att148:continous

att149:continous

att150:continous

att151:continous

att152:continous

att153:continous

att154:continous

att155:continous

att156:continous

att157:continous

att158:continous

att159:continous

att160:continous

att161:continous

att162:continous

att163:continous

att164:continous

att165:continous

att166:continous

att167:continous

att168:continous

att169:continous

att170:continous

att171:continous

att172:continous

att173:continous

att174:continous

att175:continous

att176:continous

att177:continous

att178:continous

att179:continous

att180:continous

att181:continous

att182:continous

att183:continous

att184:continous

att185:continous

att186:continous

att187:continous

att188:continous

att189:continous

att190:continous

att191:continous

att192:continous

att193:continous

att194:continous

att195:continous

att196:continous

att197:continous

att198:continous

att199:continous

att200:continous

att201:continous

att202:continous

att203:continous

att204:continous

att205:continous

att206:continous

att207:continous

att208:continous

att209:continous

att210:continous

att211:continous

att212:continous

att213:continous

att214:continous

att215:continous

att216:continous

