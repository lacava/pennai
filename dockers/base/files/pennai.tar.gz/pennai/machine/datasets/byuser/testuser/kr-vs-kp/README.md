# kr-vs-kp

## Summary Stats

#instances: 3196

#features: 36

  #binary_features: 35

  #integer_features: 1

  #float_features: 0

Endpoint type: binary

#Classes: 2

Imbalance metric: 0.001974072722317166

## Feature Types

 c1:binary

c2:binary

c3:binary

c4:binary

c5:binary

c6:binary

c7:binary

c8:binary

c9:binary

c10:binary

c11:binary

c12:binary

c13:binary

c14:binary

c15:discrete

c16:binary

c17:binary

c18:binary

c19:binary

c20:binary

c21:binary

c22:binary

c23:binary

c24:binary

c25:binary

c26:binary

c27:binary

c28:binary

c29:binary

c30:binary

c31:binary

c32:binary

c33:binary

c34:binary

c35:binary

c36:binary

