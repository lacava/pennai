# spambase

## Summary Stats

#instances: 4601

#features: 57

  #binary_features: 0

  #integer_features: 2

  #float_features: 55

Endpoint type: binary

#Classes: 2

Imbalance metric: 0.04490604062004988

## Feature Types

 0:continous

1:continous

2:continous

3:continous

4:continous

5:continous

6:continous

7:continous

8:continous

9:continous

10:continous

11:continous

12:continous

13:continous

14:continous

15:continous

16:continous

17:continous

18:continous

19:continous

20:continous

21:continous

22:continous

23:continous

24:continous

25:continous

26:continous

27:continous

28:continous

29:continous

30:continous

31:continous

32:continous

33:continous

34:continous

35:continous

36:continous

37:continous

38:continous

39:continous

40:continous

41:continous

42:continous

43:continous

44:continous

45:continous

46:continous

47:continous

48:continous

49:continous

50:continous

51:continous

52:continous

53:continous

54:continous

55:discrete

56:discrete

