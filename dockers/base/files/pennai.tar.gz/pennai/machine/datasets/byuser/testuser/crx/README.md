# crx

## Summary Stats

#instances: 690

#features: 15

  #binary_features: 3

  #integer_features: 8

  #float_features: 4

Endpoint type: binary

#Classes: 2

Imbalance metric: 0.012131905061961762

## Feature Types

 A1:discrete

A2:discrete

A3:continous

A4:discrete

A5:discrete

A6:discrete

A7:discrete

A8:continous

A9:binary

A10:binary

A11:continous

A12:binary

A13:discrete

A14:discrete

A15:continous

