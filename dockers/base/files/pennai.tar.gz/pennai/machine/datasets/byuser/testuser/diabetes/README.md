# diabetes

## Summary Stats

#instances: 768

#features: 8

  #binary_features: 0

  #integer_features: 0

  #float_features: 8

Endpoint type: binary

#Classes: 2

Imbalance metric: 0.09125434027777776

## Feature Types

 A1:continous

A2:continous

A3:continous

A4:continous

A5:continous

A6:continous

A7:continous

A8:continous

