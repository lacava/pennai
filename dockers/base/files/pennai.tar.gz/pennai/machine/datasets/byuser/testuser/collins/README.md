# collins

## Summary Stats

#instances: 485

#features: 23

  #binary_features: 1

  #integer_features: 2

  #float_features: 20

Endpoint type: integer

#Classes: 13

Imbalance metric: 0.0219810819428207

## Feature Types

 Text:discrete

FirstPerson:continous

InnerThinking:continous

ThinkPositive:continous

ThinkNegative:continous

ThinkAhead:continous

ThinkBack:continous

Reasoning:continous

Share_SocTies:continous

Direct_Activity:continous

Interacting:continous

Notifying:continous

LinearGuidance:continous

WordPicture:continous

SpaceInterval:continous

Motion:continous

PastEvents:continous

TimeInterval:continous

ShiftingEvents:continous

Text_Coverage:continous

Genre:discrete

Counter:continous

Corpus:binary

