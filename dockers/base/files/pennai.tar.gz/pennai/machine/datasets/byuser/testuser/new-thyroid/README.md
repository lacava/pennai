# new-thyroid

## Summary Stats

#instances: 215

#features: 5

  #binary_features: 0

  #integer_features: 0

  #float_features: 5

Endpoint type: integer

#Classes: 3

Imbalance metric: 0.29908058409951327

## Feature Types

 2:continous

3:continous

4:continous

5:continous

6:continous

