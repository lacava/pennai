# optdigits

## Summary Stats

#instances: 5620

#features: 64

  #binary_features: 0

  #integer_features: 0

  #float_features: 64

Endpoint type: integer

#Classes: 10

Imbalance metric: 1.470486836680272e-05

## Feature Types

 input1:continous

input2:continous

input3:continous

input4:continous

input5:continous

input6:continous

input7:continous

input8:continous

input9:continous

input10:continous

input11:continous

input12:continous

input13:continous

input14:continous

input15:continous

input16:continous

input17:continous

input18:continous

input19:continous

input20:continous

input21:continous

input22:continous

input23:continous

input24:continous

input25:continous

input26:continous

input27:continous

input28:continous

input29:continous

input30:continous

input31:continous

input32:continous

input33:continous

input34:continous

input35:continous

input36:continous

input37:continous

input38:continous

input39:continous

input40:continous

input41:continous

input42:continous

input43:continous

input44:continous

input45:continous

input46:continous

input47:continous

input48:continous

input49:continous

input50:continous

input51:continous

input52:continous

input53:continous

input54:continous

input55:continous

input56:continous

input57:continous

input58:continous

input59:continous

input60:continous

input61:continous

input62:continous

input63:continous

input64:continous

