# ring

## Summary Stats

#instances: 7400

#features: 20

  #binary_features: 0

  #integer_features: 0

  #float_features: 20

Endpoint type: binary

#Classes: 2

Imbalance metric: 9.46676406135857e-05

## Feature Types

 A1:continous

A2:continous

A3:continous

A4:continous

A5:continous

A6:continous

A7:continous

A8:continous

A9:continous

A10:continous

A11:continous

A12:continous

A13:continous

A14:continous

A15:continous

A16:continous

A17:continous

A18:continous

A19:continous

A20:continous

