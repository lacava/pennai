# hayes-roth

## Summary Stats

#instances: 160

#features: 4

  #binary_features: 0

  #integer_features: 0

  #float_features: 4

Endpoint type: integer

#Classes: 3

Imbalance metric: 0.043867187499999995

## Feature Types

 Hobby:continous

Age:continous

Education:continous

Marital status:continous

