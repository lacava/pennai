# mfeat-morphological

## Summary Stats

#instances: 2000

#features: 6

  #binary_features: 0

  #integer_features: 0

  #float_features: 6

Endpoint type: integer

#Classes: 10

Imbalance metric: 0.0

## Feature Types

 att1:continous

att2:continous

att3:continous

att4:continous

att5:continous

att6:continous

