# page-blocks

## Summary Stats

#instances: 5473

#features: 10

  #binary_features: 0

  #integer_features: 0

  #float_features: 10

Endpoint type: integer

#Classes: 5

Imbalance metric: 0.7627104291422278

## Feature Types

 height:continous

lenght:continous

area:continous

eccen:continous

p_black:continous

p_and:continous

mean_tr:continous

blackpix:continous

blackand:continous

wb_trans:continous

