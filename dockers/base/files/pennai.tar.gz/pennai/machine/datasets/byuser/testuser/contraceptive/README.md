# contraceptive

## Summary Stats

#instances: 1473

#features: 9

  #binary_features: 3

  #integer_features: 6

  #float_features: 0

Endpoint type: integer

#Classes: 3

Imbalance metric: 0.03070060823264104

## Feature Types

 Wife_age:discrete

Wife_education:discrete

Husband_education:discrete

Children:discrete

Wife_religion:binary

Wife_working:binary

Husband_occupation:discrete

Standard-of-living:discrete

Media_exposure:binary

