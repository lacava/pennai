# wine-quality-white

## Summary Stats

#instances: 4893

#features: 11

  #binary_features: 0

  #integer_features: 0

  #float_features: 11

Endpoint type: integer

#Classes: 6

Imbalance metric: 0.19025442445024934

## Feature Types

 fixed acidity:continous

volatile acidity:continous

citric acid:continous

residual sugar:continous

chlorides:continous

free sulfur dioxide:continous

total sulfur dioxide:continous

density:continous

pH:continous

sulphates:continous

alcohol:continous

