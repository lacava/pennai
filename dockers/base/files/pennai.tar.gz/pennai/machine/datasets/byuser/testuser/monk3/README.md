# monk3

## Summary Stats

#instances: 554

#features: 6

  #binary_features: 2

  #integer_features: 4

  #float_features: 0

Endpoint type: binary

#Classes: 2

Imbalance metric: 0.0015769787173037539

## Feature Types

 Head shape:discrete

Body shape:discrete

Is smiling:binary

Holding:discrete

Jacket color:discrete

Has tie:binary

