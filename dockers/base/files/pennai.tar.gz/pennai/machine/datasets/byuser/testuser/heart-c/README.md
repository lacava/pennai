# heart-c

## Summary Stats

#instances: 303

#features: 13

  #binary_features: 3

  #integer_features: 5

  #float_features: 5

Endpoint type: binary

#Classes: 2

Imbalance metric: 0.007940398000196063

## Feature Types

 age:continous

sex:binary

cp:discrete

trestbps:continous

chol:continous

fbs:binary

restecg:discrete

thalach:continous

exang:binary

oldpeak:continous

slope:discrete

ca:discrete

thal:discrete

