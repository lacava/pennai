# sonar

## Summary Stats

#instances: 208

#features: 60

  #binary_features: 0

  #integer_features: 0

  #float_features: 60

Endpoint type: binary

#Classes: 2

Imbalance metric: 0.00453032544378698

## Feature Types

 A1:continous

A2:continous

A3:continous

A4:continous

A5:continous

A6:continous

A7:continous

A8:continous

A9:continous

A10:continous

A11:continous

A12:continous

A13:continous

A14:continous

A15:continous

A16:continous

A17:continous

A18:continous

A19:continous

A20:continous

A21:continous

A22:continous

A23:continous

A24:continous

A25:continous

A26:continous

A27:continous

A28:continous

A29:continous

A30:continous

A31:continous

A32:continous

A33:continous

A34:continous

A35:continous

A36:continous

A37:continous

A38:continous

A39:continous

A40:continous

A41:continous

A42:continous

A43:continous

A44:continous

A45:continous

A46:continous

A47:continous

A48:continous

A49:continous

A50:continous

A51:continous

A52:continous

A53:continous

A54:continous

A55:continous

A56:continous

A57:continous

A58:continous

A59:continous

A60:continous

