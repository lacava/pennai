# saheart

## Summary Stats

#instances: 462

#features: 9

  #binary_features: 1

  #integer_features: 3

  #float_features: 5

Endpoint type: binary

#Classes: 2

Imbalance metric: 0.09446974382039316

## Feature Types

 Sbp:discrete

Tobacco:continous

Ldl:continous

Adiposity:continous

Famhist:binary

Typea:discrete

Obesity:continous

Alcohol:continous

Age:discrete

