# flags

## Summary Stats

#instances: 178

#features: 43

  #binary_features: 36

  #integer_features: 7

  #float_features: 0

Endpoint type: integer

#Classes: 5

Imbalance metric: 0.04391806590077009

## Feature Types

 bars:discrete

stripes:discrete

colors:discrete

red:binary

green:binary

blue:binary

gold:binary

white:binary

black:binary

orange:binary

circles:discrete

crosses:discrete

saltires:binary

quarters:discrete

sunstars:discrete

crescent:binary

triangle:binary

icon:binary

animate:binary

text:binary

mainhue_green:binary

mainhue_red:binary

mainhue_blue:binary

mainhue_gold:binary

mainhue_white:binary

mainhue_orange:binary

mainhue_black:binary

mainhue_brown:binary

topleft_black:binary

topleft_red:binary

topleft_green:binary

topleft_blue:binary

topleft_white:binary

topleft_orange:binary

topleft_gold:binary

botright_green:binary

botright_red:binary

botright_white:binary

botright_black:binary

botright_blue:binary

botright_gold:binary

botright_orange:binary

botright_brown:binary

