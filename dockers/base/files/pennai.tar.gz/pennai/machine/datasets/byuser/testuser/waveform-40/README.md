# waveform-40

## Summary Stats

#instances: 5000

#features: 40

  #binary_features: 0

  #integer_features: 0

  #float_features: 40

Endpoint type: integer

#Classes: 3

Imbalance metric: 5.787999999999951e-05

## Feature Types

 X00:continous

X01:continous

X02:continous

X03:continous

X04:continous

X05:continous

X06:continous

X07:continous

X08:continous

X09:continous

X10:continous

X11:continous

X12:continous

X13:continous

X14:continous

X15:continous

X16:continous

X17:continous

X18:continous

X19:continous

X20:continous

X21:continous

X22:continous

X23:continous

X24:continous

X25:continous

X26:continous

X27:continous

X28:continous

X29:continous

X30:continous

X31:continous

X32:continous

X33:continous

X34:continous

X35:continous

X36:continous

X37:continous

X38:continous

X39:continous

