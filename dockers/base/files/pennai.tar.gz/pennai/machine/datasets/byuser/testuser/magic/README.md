# magic

## Summary Stats

#instances: 19020

#features: 10

  #binary_features: 0

  #integer_features: 0

  #float_features: 10

Endpoint type: binary

#Classes: 2

Imbalance metric: 0.08805478985538495

## Feature Types

 FLength:continous

FWidth:continous

FSize:continous

FConc:continous

FConc1:continous

FAsym:continous

FM3Long:continous

FM3Trans:continous

FAlpha:continous

FDist:continous

