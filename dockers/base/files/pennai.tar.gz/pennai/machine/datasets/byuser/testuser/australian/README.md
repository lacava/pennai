# australian

## Summary Stats

#instances: 690

#features: 14

  #binary_features: 4

  #integer_features: 4

  #float_features: 6

Endpoint type: binary

#Classes: 2

Imbalance metric: 0.012131905061961762

## Feature Types

 A1:binary

A2:continous

A3:continous

A4:discrete

A5:discrete

A6:discrete

A7:continous

A8:binary

A9:binary

A10:continous

A11:binary

A12:discrete

A13:continous

A14:continous

