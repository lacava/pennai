# glass

## Summary Stats

#instances: 205

#features: 9

  #binary_features: 0

  #integer_features: 0

  #float_features: 9

Endpoint type: integer

#Classes: 5

Imbalance metric: 0.10618679357525282

## Feature Types

 RI:continous

Na:continous

Mg:continous

Al:continous

Si:continous

K:continous

Ca:continous

Ba:continous

Fe:continous

