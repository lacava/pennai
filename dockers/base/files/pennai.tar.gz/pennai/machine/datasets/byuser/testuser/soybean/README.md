# soybean

## Summary Stats

#instances: 675

#features: 35

  #binary_features: 1

  #integer_features: 34

  #float_features: 0

Endpoint type: integer

#Classes: 18

Imbalance metric: 0.03626782861292665

## Feature Types

 date:discrete

plant-stand:discrete

precip:discrete

temp:discrete

hail:discrete

crop-hist:discrete

area-damaged:discrete

severity:discrete

seed-tmt:discrete

germination:discrete

plant-growth:discrete

leaves:binary

leafspots-halo:discrete

leafspots-marg:discrete

leafspot-size:discrete

leaf-shread:discrete

leaf-malf:discrete

leaf-mild:discrete

stem:discrete

lodging:discrete

stem-cankers:discrete

canker-lesion:discrete

fruiting-bodies:discrete

external-decay:discrete

mycelium:discrete

int-discolor:discrete

sclerotia:discrete

fruit-pods:discrete

fruit-spots:discrete

seed:discrete

mold-growth:discrete

seed-discolor:discrete

seed-size:discrete

shriveling:discrete

roots:discrete

