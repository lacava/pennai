# Hill_Valley_with_noise

## Summary Stats

#instances: 1212

#features: 100

  #binary_features: 0

  #integer_features: 0

  #float_features: 100

Endpoint type: binary

#Classes: 2

Imbalance metric: 0.0

## Feature Types

 X1:continous

X2:continous

X3:continous

X4:continous

X5:continous

X6:continous

X7:continous

X8:continous

X9:continous

X10:continous

X11:continous

X12:continous

X13:continous

X14:continous

X15:continous

X16:continous

X17:continous

X18:continous

X19:continous

X20:continous

X21:continous

X22:continous

X23:continous

X24:continous

X25:continous

X26:continous

X27:continous

X28:continous

X29:continous

X30:continous

X31:continous

X32:continous

X33:continous

X34:continous

X35:continous

X36:continous

X37:continous

X38:continous

X39:continous

X40:continous

X41:continous

X42:continous

X43:continous

X44:continous

X45:continous

X46:continous

X47:continous

X48:continous

X49:continous

X50:continous

X51:continous

X52:continous

X53:continous

X54:continous

X55:continous

X56:continous

X57:continous

X58:continous

X59:continous

X60:continous

X61:continous

X62:continous

X63:continous

X64:continous

X65:continous

X66:continous

X67:continous

X68:continous

X69:continous

X70:continous

X71:continous

X72:continous

X73:continous

X74:continous

X75:continous

X76:continous

X77:continous

X78:continous

X79:continous

X80:continous

X81:continous

X82:continous

X83:continous

X84:continous

X85:continous

X86:continous

X87:continous

X88:continous

X89:continous

X90:continous

X91:continous

X92:continous

X93:continous

X94:continous

X95:continous

X96:continous

X97:continous

X98:continous

X99:continous

X100:continous

