# chess

## Summary Stats

#instances: 3196

#features: 36

  #binary_features: 35

  #integer_features: 1

  #float_features: 0

Endpoint type: binary

#Classes: 2

Imbalance metric: 0.001974072722317166

## Feature Types

 A00:binary

A01:binary

A02:binary

A03:binary

A04:binary

A05:binary

A06:binary

A07:binary

A08:binary

A09:binary

A10:binary

A11:binary

A12:binary

A13:binary

A14:discrete

A15:binary

A16:binary

A17:binary

A18:binary

A19:binary

A20:binary

A21:binary

A22:binary

A23:binary

A24:binary

A25:binary

A26:binary

A27:binary

A28:binary

A29:binary

A30:binary

A31:binary

A32:binary

A33:binary

A34:binary

A35:binary

