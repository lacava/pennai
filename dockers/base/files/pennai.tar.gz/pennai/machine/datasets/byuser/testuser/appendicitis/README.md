# appendicitis

## Summary Stats

#instances: 106

#features: 7

  #binary_features: 0

  #integer_features: 0

  #float_features: 7

Endpoint type: binary

#Classes: 2

Imbalance metric: 0.3645425418298327

## Feature Types

 At1:continous

At2:continous

At3:continous

At4:continous

At5:continous

At6:continous

At7:continous

