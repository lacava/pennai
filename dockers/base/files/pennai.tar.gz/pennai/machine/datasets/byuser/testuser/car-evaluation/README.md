# car-evaluation

## Summary Stats

#instances: 1728

#features: 21

  #binary_features: 21

  #integer_features: 0

  #float_features: 0

Endpoint type: integer

#Classes: 4

Imbalance metric: 0.39028831590077734

## Feature Types

 buying_price_vhigh:binary

buying_price_high:binary

buying_price_med:binary

buying_price_low:binary

maintenance_price_vhigh:binary

maintenance_price_high:binary

maintenance_price_med:binary

maintenance_price_low:binary

doors_2:binary

doors_3:binary

doors_4:binary

doors_5more:binary

persons_2:binary

persons_4:binary

persons_more:binary

luggage_boot_size_small:binary

luggage_boot_size_med:binary

luggage_boot_size_big:binary

safety_low:binary

safety_med:binary

safety_high:binary

