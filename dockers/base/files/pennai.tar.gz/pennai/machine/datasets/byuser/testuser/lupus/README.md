# lupus

## Summary Stats

#instances: 87

#features: 3

  #binary_features: 0

  #integer_features: 0

  #float_features: 3

Endpoint type: binary

#Classes: 2

Imbalance metric: 0.038182058396089326

## Feature Types

 TIME:continous

DURATION:continous

LOG(1+DURATION):continous

