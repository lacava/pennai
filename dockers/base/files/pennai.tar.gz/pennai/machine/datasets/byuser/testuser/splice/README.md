# splice

## Summary Stats

#instances: 3188

#features: 60

  #binary_features: 0

  #integer_features: 60

  #float_features: 0

Endpoint type: integer

#Classes: 3

Imbalance metric: 0.07767630417705039

## Feature Types

 A0:discrete

A1:discrete

A2:discrete

A3:discrete

A4:discrete

A5:discrete

A6:discrete

A7:discrete

A8:discrete

A9:discrete

A10:discrete

A11:discrete

A12:discrete

A13:discrete

A14:discrete

A15:discrete

A16:discrete

A17:discrete

A18:discrete

A19:discrete

A20:discrete

A21:discrete

A22:discrete

A23:discrete

A24:discrete

A25:discrete

A26:discrete

A27:discrete

A28:discrete

A29:discrete

A30:discrete

A31:discrete

A32:discrete

A33:discrete

A34:discrete

A35:discrete

A36:discrete

A37:discrete

A38:discrete

A39:discrete

A40:discrete

A41:discrete

A42:discrete

A43:discrete

A44:discrete

A45:discrete

A46:discrete

A47:discrete

A48:discrete

A49:discrete

A50:discrete

A51:discrete

A52:discrete

A53:discrete

A54:discrete

A55:discrete

A56:discrete

A57:discrete

A58:discrete

A59:discrete

