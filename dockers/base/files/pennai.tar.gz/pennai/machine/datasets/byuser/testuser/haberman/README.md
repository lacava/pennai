# haberman

## Summary Stats

#instances: 306

#features: 3

  #binary_features: 0

  #integer_features: 1

  #float_features: 2

Endpoint type: binary

#Classes: 2

Imbalance metric: 0.2214532871972319

## Feature Types

 Age_of_patient_at_time_of_operation:continous

Patients_year_of_operation:discrete

Number_of_positive_axillary_nodes_detected:continous

