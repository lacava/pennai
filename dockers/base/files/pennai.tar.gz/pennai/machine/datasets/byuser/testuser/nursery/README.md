# nursery

## Summary Stats

#instances: 12958

#features: 8

  #binary_features: 1

  #integer_features: 7

  #float_features: 0

Endpoint type: integer

#Classes: 4

Imbalance metric: 0.09008993664001576

## Feature Types

 parents:discrete

has_nurs:discrete

form:discrete

children:discrete

housing:discrete

finance:binary

social:discrete

health:discrete

