# molecular-biology_promoters

## Summary Stats

#instances: 106

#features: 58

  #binary_features: 0

  #integer_features: 58

  #float_features: 0

Endpoint type: binary

#Classes: 2

Imbalance metric: 0.0

## Feature Types

 instance:discrete

p-50:discrete

p-49:discrete

p-48:discrete

p-47:discrete

p-46:discrete

p-45:discrete

p-44:discrete

p-43:discrete

p-42:discrete

p-41:discrete

p-40:discrete

p-39:discrete

p-38:discrete

p-37:discrete

p-36:discrete

p-35:discrete

p-34:discrete

p-33:discrete

p-32:discrete

p-31:discrete

p-30:discrete

p-29:discrete

p-28:discrete

p-27:discrete

p-26:discrete

p-25:discrete

p-24:discrete

p-23:discrete

p-22:discrete

p-21:discrete

p-20:discrete

p-19:discrete

p-18:discrete

p-17:discrete

p-16:discrete

p-15:discrete

p-14:discrete

p-13:discrete

p-12:discrete

p-11:discrete

p-10:discrete

p-9:discrete

p-8:discrete

p-7:discrete

p-6:discrete

p-5:discrete

p-4:discrete

p-3:discrete

p-2:discrete

p-1:discrete

p1:discrete

p2:discrete

p3:discrete

p4:discrete

p5:discrete

p6:discrete

p7:discrete

