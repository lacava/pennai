# spect

## Summary Stats

#instances: 267

#features: 22

  #binary_features: 22

  #integer_features: 0

  #float_features: 0

Endpoint type: binary

#Classes: 2

Imbalance metric: 0.3457616182019667

## Feature Types

 F1:binary

F2:binary

F3:binary

F4:binary

F5:binary

F6:binary

F7:binary

F8:binary

F9:binary

F10:binary

F11:binary

F12:binary

F13:binary

F14:binary

F15:binary

F16:binary

F17:binary

F18:binary

F19:binary

F20:binary

F21:binary

F22:binary

