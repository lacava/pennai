# segmentation

## Summary Stats

#instances: 2310

#features: 19

  #binary_features: 0

  #integer_features: 0

  #float_features: 19

Endpoint type: integer

#Classes: 7

Imbalance metric: 0.0

## Feature Types

 region-centroid-col:continous

region-centroid-row:continous

region-pixel-count:continous

short-line-density-5:continous

short-line-density-2:continous

vedge-mean:continous

vedge-sd:continous

hedge-mean:continous

hedge-sd:continous

intensity-mean:continous

rawred-mean:continous

rawblue-mean:continous

rawgreen-mean:continous

exred-mean:continous

exblue-mean:continous

exgreen-mean:continous

value-mean:continous

saturatoin-mean:continous

hue-mean:continous

