# balance-scale

## Summary Stats

#instances: 625

#features: 4

  #binary_features: 0

  #integer_features: 4

  #float_features: 0

Endpoint type: integer

#Classes: 3

Imbalance metric: 0.14622976

## Feature Types

 Left-Weight:discrete

Left-Distance:discrete

Right-Weight:discrete

Right-Distance:discrete

