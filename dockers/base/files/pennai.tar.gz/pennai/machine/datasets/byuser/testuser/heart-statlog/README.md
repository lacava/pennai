# heart-statlog

## Summary Stats

#instances: 270

#features: 13

  #binary_features: 0

  #integer_features: 0

  #float_features: 13

Endpoint type: binary

#Classes: 2

Imbalance metric: 0.01234567901234569

## Feature Types

 age:continous

sex:continous

chest:continous

resting_blood_pressure:continous

serum_cholestoral:continous

fasting_blood_sugar:continous

resting_electrocardiographic_results:continous

maximum_heart_rate_achieved:continous

exercise_induced_angina:continous

oldpeak:continous

slope:continous

number_of_major_vessels:continous

thal:continous

