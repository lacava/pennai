# colic

## Summary Stats

#instances: 368

#features: 22

  #binary_features: 1

  #integer_features: 21

  #float_features: 0

Endpoint type: binary

#Classes: 2

Imbalance metric: 0.0680529300567108

## Feature Types

 surgery:discrete

Age:binary

rectal_temperature:discrete

pulse:discrete

respiratory_rate:discrete

temp_extremities:discrete

peripheral_pulse:discrete

mucous_membranes:discrete

capillary_refill_time:discrete

pain:discrete

peristalsis:discrete

abdominal_distension:discrete

nasogastric_tube:discrete

nasogastric_reflux:discrete

nasogastric_reflux_PH:discrete

rectal_examination:discrete

abdomen:discrete

packed_cell_volume:discrete

total_protein:discrete

abdominocentesis_appearance:discrete

abdomcentesis_total_protein:discrete

outcome:discrete

