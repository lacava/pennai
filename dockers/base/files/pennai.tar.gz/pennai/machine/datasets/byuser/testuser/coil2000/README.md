# coil2000

## Summary Stats

#instances: 9822

#features: 85

  #binary_features: 5

  #integer_features: 80

  #float_features: 0

Endpoint type: binary

#Classes: 2

Imbalance metric: 0.7755902757953309

## Feature Types

 MOSTYPE:discrete

MAANTHUI:discrete

MGEMOMV:discrete

MGEMLEEF:discrete

MOSHOOFD:discrete

MGODRK:discrete

MGODPR:discrete

MGODOV:discrete

MGODGE:discrete

MRELGE:discrete

MRELSA:discrete

MRELOV:discrete

MFALLEEN:discrete

MFGEKIND:discrete

MFWEKIND:discrete

MOPLHOOG:discrete

MOPLMIDD:discrete

MOPLLAAG:discrete

MBERHOOG:discrete

MBERZELF:discrete

MBERBOER:discrete

MBERMIDD:discrete

MBERARBG:discrete

MBERARBO:discrete

MSKA:discrete

MSKB1:discrete

MSKB2:discrete

MSKC:discrete

MSKD:discrete

MHHUUR:discrete

MHKOOP:discrete

MAUT1:discrete

MAUT2:discrete

MAUT0:discrete

MZFONDS:discrete

MZPART:discrete

MINKM30:discrete

MINK3045:discrete

MINK4575:discrete

MINK7512:discrete

MINK123M:discrete

MINKGEM:discrete

MKOOPKLA:discrete

PWAPART:discrete

PWABEDR:discrete

PWALAND:discrete

PPERSAUT:discrete

PBESAUT:discrete

PMOTSCO:discrete

PVRAAUT:discrete

PAANHANG:discrete

PTRACTOR:discrete

PWERKT:discrete

PBROM:discrete

PLEVEN:discrete

PPERSONG:discrete

PGEZONG:discrete

PWAOREG:discrete

PBRAND:discrete

PZEILPL:discrete

PPLEZIER:discrete

PFIETS:binary

PINBOED:discrete

PBYSTAND:discrete

AWAPART:discrete

AWABEDR:discrete

AWALAND:binary

APERSAUT:discrete

ABESAUT:discrete

AMOTSCO:discrete

AVRAAUT:discrete

AAANHANG:discrete

ATRACTOR:discrete

AWERKT:discrete

ABROM:discrete

ALEVEN:discrete

APERSONG:binary

AGEZONG:binary

AWAOREG:discrete

ABRAND:discrete

AZEILPL:binary

APLEZIER:discrete

AFIETS:discrete

AINBOED:discrete

ABYSTAND:discrete

