# monk2

## Summary Stats

#instances: 601

#features: 6

  #binary_features: 0

  #integer_features: 6

  #float_features: 0

Endpoint type: binary

#Classes: 2

Imbalance metric: 0.09889507504132047

## Feature Types

 attribute#1:discrete

attribute#2:discrete

attribute#3:binary

attribute#4:discrete

attribute#5:discrete

attribute#6:binary

