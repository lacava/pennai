# house-votes-84

## Summary Stats

#instances: 435

#features: 16

  #binary_features: 0

  #integer_features: 16

  #float_features: 0

Endpoint type: binary

#Classes: 2

Imbalance metric: 0.05179548156956005

## Feature Types

 handicapped-infants:discrete

water-project-cost-sharing:discrete

adoption-of-the-budget-resolution:discrete

physician-fee-freeze:discrete

el-salvador-adi:discrete

religious-groups-in-schools:discrete

anti-satellite-test-ban:discrete

aid-to-nicaraguan-contras:discrete

mx-missile:discrete

immigration:discrete

synfuels-corporation-cutback:discrete

education-spending:discrete

superfund-right-to-sue:discrete

crime:discrete

duty-free-exports:discrete

export-administration-act-south-africa:discrete

