# vehicle

## Summary Stats

#instances: 846

#features: 18

  #binary_features: 0

  #integer_features: 0

  #float_features: 18

Endpoint type: integer

#Classes: 4

Imbalance metric: 0.0004266124179609407

## Feature Types

 COMPACTNESS:continous

CIRCULARITY:continous

DISTANCE CIRCULARITY:continous

RADIUS RATIO:continous

PR AXIS ASPECT RATIO:continous

MAX LENGTH ASPECT RATIO:continous

SCATTER RATIO:continous

ELONGATEDNESS:continous

PR AXISRECTANGULAR:continous

LENGTHRECTANGULAR:continous

MAJORVARIANCE:continous

MINORVARIANCE:continous

GYRATIONRADIUS:continous

MAJORSKEWNESS:continous

MINORSKEWNESS:continous

MINORKURTOSIS:continous

MAJORKURTOSIS:continous

HOLLOWS RATIO:continous

