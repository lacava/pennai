# corral

## Summary Stats

#instances: 160

#features: 6

  #binary_features: 6

  #integer_features: 0

  #float_features: 0

Endpoint type: binary

#Classes: 2

Imbalance metric: 0.015625

## Feature Types

 A0:binary

A1:binary

B0:binary

B1:binary

Irrelevant:binary

Correlated:binary

