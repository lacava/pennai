# parity5+5

## Summary Stats

#instances: 1124

#features: 10

  #binary_features: 10

  #integer_features: 0

  #float_features: 0

Endpoint type: binary

#Classes: 2

Imbalance metric: 7.915299958207264e-05

## Feature Types

 Bit 1:binary

Bit 2:binary

Bit 3:binary

Bit 4:binary

Bit 5:binary

Bit 6:binary

Bit 7:binary

Bit 8:binary

Bit 9:binary

Bit 10:binary

