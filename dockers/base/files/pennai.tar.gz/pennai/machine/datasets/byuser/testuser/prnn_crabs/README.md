# prnn_crabs

## Summary Stats

#instances: 200

#features: 7

  #binary_features: 1

  #integer_features: 0

  #float_features: 6

Endpoint type: binary

#Classes: 2

Imbalance metric: 0.0

## Feature Types

 sex:binary

index:continous

FL:continous

RW:continous

CL:continous

CW:continous

BD:continous

