# banana

## Summary Stats

#instances: 5300

#features: 2

  #binary_features: 0

  #integer_features: 0

  #float_features: 2

Endpoint type: binary

#Classes: 2

Imbalance metric: 0.010690779636881451

## Feature Types

 At1:continous

At2:continous

