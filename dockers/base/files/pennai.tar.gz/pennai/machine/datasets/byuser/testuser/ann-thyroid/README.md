# ann-thyroid

## Summary Stats

#instances: 7200

#features: 21

  #binary_features: 15

  #integer_features: 0

  #float_features: 6

Endpoint type: integer

#Classes: 3

Imbalance metric: 0.7904668981481481

## Feature Types

 A1:continous

A2:binary

A3:binary

A4:binary

A5:binary

A6:binary

A7:binary

A8:binary

A9:binary

A10:binary

A11:binary

A12:binary

A13:binary

A14:binary

A15:binary

A16:binary

A17:continous

A18:continous

A19:continous

A20:continous

A21:continous

