# phoneme

## Summary Stats

#instances: 5404

#features: 5

  #binary_features: 0

  #integer_features: 0

  #float_features: 5

Endpoint type: binary

#Classes: 2

Imbalance metric: 0.1705916225117124

## Feature Types

 Aa:continous

Ao:continous

Dcl:continous

Iy:continous

Sh:continous

