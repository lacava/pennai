# schizo

## Summary Stats

#instances: 340

#features: 14

  #binary_features: 1

  #integer_features: 12

  #float_features: 1

Endpoint type: binary

#Classes: 2

Imbalance metric: 0.001695501730103808

## Feature Types

 ID:continous

target:discrete

gain_ratio_1:discrete

gain_ratio_2:discrete

gain_ratio_3:discrete

gain_ratio_4:discrete

gain_ratio_5:discrete

gain_ratio_6:discrete

gain_ratio_7:discrete

gain_ratio_8:discrete

gain_ratio_9:discrete

gain_ratio_10:discrete

gain_ratio_11:discrete

sex:binary

