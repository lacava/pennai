# mfeat-pixel

## Summary Stats

#instances: 2000

#features: 240

  #binary_features: 0

  #integer_features: 0

  #float_features: 240

Endpoint type: integer

#Classes: 10

Imbalance metric: 0.0

## Feature Types

 attribute_0:continous

attribute_1:continous

attribute_2:continous

attribute_3:continous

attribute_4:continous

attribute_5:continous

attribute_6:continous

attribute_7:continous

attribute_8:continous

attribute_9:continous

attribute_10:continous

attribute_11:continous

attribute_12:continous

attribute_13:continous

attribute_14:continous

attribute_15:continous

attribute_16:continous

attribute_17:continous

attribute_18:continous

attribute_19:continous

attribute_20:continous

attribute_21:continous

attribute_22:continous

attribute_23:continous

attribute_24:continous

attribute_25:continous

attribute_26:continous

attribute_27:continous

attribute_28:continous

attribute_29:continous

attribute_30:continous

attribute_31:continous

attribute_32:continous

attribute_33:continous

attribute_34:continous

attribute_35:continous

attribute_36:continous

attribute_37:continous

attribute_38:continous

attribute_39:continous

attribute_40:continous

attribute_41:continous

attribute_42:continous

attribute_43:continous

attribute_44:continous

attribute_45:continous

attribute_46:continous

attribute_47:continous

attribute_48:continous

attribute_49:continous

attribute_50:continous

attribute_51:continous

attribute_52:continous

attribute_53:continous

attribute_54:continous

attribute_55:continous

attribute_56:continous

attribute_57:continous

attribute_58:continous

attribute_59:continous

attribute_60:continous

attribute_61:continous

attribute_62:continous

attribute_63:continous

attribute_64:continous

attribute_65:continous

attribute_66:continous

attribute_67:continous

attribute_68:continous

attribute_69:continous

attribute_70:continous

attribute_71:continous

attribute_72:continous

attribute_73:continous

attribute_74:continous

attribute_75:continous

attribute_76:continous

attribute_77:continous

attribute_78:continous

attribute_79:continous

attribute_80:continous

attribute_81:continous

attribute_82:continous

attribute_83:continous

attribute_84:continous

attribute_85:continous

attribute_86:continous

attribute_87:continous

attribute_88:continous

attribute_89:continous

attribute_90:continous

attribute_91:continous

attribute_92:continous

attribute_93:continous

attribute_94:continous

attribute_95:continous

attribute_96:continous

attribute_97:continous

attribute_98:continous

attribute_99:continous

attribute_100:continous

attribute_101:continous

attribute_102:continous

attribute_103:continous

attribute_104:continous

attribute_105:continous

attribute_106:continous

attribute_107:continous

attribute_108:continous

attribute_109:continous

attribute_110:continous

attribute_111:continous

attribute_112:continous

attribute_113:continous

attribute_114:continous

attribute_115:continous

attribute_116:continous

attribute_117:continous

attribute_118:continous

attribute_119:continous

attribute_120:continous

attribute_121:continous

attribute_122:continous

attribute_123:continous

attribute_124:continous

attribute_125:continous

attribute_126:continous

attribute_127:continous

attribute_128:continous

attribute_129:continous

attribute_130:continous

attribute_131:continous

attribute_132:continous

attribute_133:continous

attribute_134:continous

attribute_135:continous

attribute_136:continous

attribute_137:continous

attribute_138:continous

attribute_139:continous

attribute_140:continous

attribute_141:continous

attribute_142:continous

attribute_143:continous

attribute_144:continous

attribute_145:continous

attribute_146:continous

attribute_147:continous

attribute_148:continous

attribute_149:continous

attribute_150:continous

attribute_151:continous

attribute_152:continous

attribute_153:continous

attribute_154:continous

attribute_155:continous

attribute_156:continous

attribute_157:continous

attribute_158:continous

attribute_159:continous

attribute_160:continous

attribute_161:continous

attribute_162:continous

attribute_163:continous

attribute_164:continous

attribute_165:continous

attribute_166:continous

attribute_167:continous

attribute_168:continous

attribute_169:continous

attribute_170:continous

attribute_171:continous

attribute_172:continous

attribute_173:continous

attribute_174:continous

attribute_175:continous

attribute_176:continous

attribute_177:continous

attribute_178:continous

attribute_179:continous

attribute_180:continous

attribute_181:continous

attribute_182:continous

attribute_183:continous

attribute_184:continous

attribute_185:continous

attribute_186:continous

attribute_187:continous

attribute_188:continous

attribute_189:continous

attribute_190:continous

attribute_191:continous

attribute_192:continous

attribute_193:continous

attribute_194:continous

attribute_195:continous

attribute_196:continous

attribute_197:continous

attribute_198:continous

attribute_199:continous

attribute_200:continous

attribute_201:continous

attribute_202:continous

attribute_203:continous

attribute_204:continous

attribute_205:continous

attribute_206:continous

attribute_207:continous

attribute_208:continous

attribute_209:continous

attribute_210:continous

attribute_211:continous

attribute_212:continous

attribute_213:continous

attribute_214:continous

attribute_215:continous

attribute_216:continous

attribute_217:continous

attribute_218:continous

attribute_219:continous

attribute_220:continous

attribute_221:continous

attribute_222:continous

attribute_223:continous

attribute_224:continous

attribute_225:continous

attribute_226:continous

attribute_227:continous

attribute_228:continous

attribute_229:continous

attribute_230:continous

attribute_231:continous

attribute_232:continous

attribute_233:continous

attribute_234:continous

attribute_235:continous

attribute_236:continous

attribute_237:continous

attribute_238:continous

attribute_239:continous

