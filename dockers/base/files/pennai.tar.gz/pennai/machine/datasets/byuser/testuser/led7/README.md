# led7

## Summary Stats

#instances: 3200

#features: 7

  #binary_features: 7

  #integer_features: 0

  #float_features: 0

Endpoint type: integer

#Classes: 10

Imbalance metric: 0.0004364149305555553

## Feature Types

 attribute#1:binary

attribute#2:binary

attribute#3:binary

attribute#4:binary

attribute#5:binary

attribute#6:binary

attribute#7:binary

