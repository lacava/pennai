# profb

## Summary Stats

#instances: 672

#features: 9

  #binary_features: 1

  #integer_features: 3

  #float_features: 5

Endpoint type: binary

#Classes: 2

Imbalance metric: 0.1111111111111111

## Feature Types

 Overtime:binary

Favorite_Points:continous

Underdog_Points:continous

Pointspread:continous

Favorite_Name:discrete

Underdog_name:discrete

Year:continous

Week:continous

Weekday:discrete

