# parity5

## Summary Stats

#instances: 32

#features: 5

  #binary_features: 5

  #integer_features: 0

  #float_features: 0

Endpoint type: binary

#Classes: 2

Imbalance metric: 0.0

## Feature Types

 Bit 1:binary

Bit 2:binary

Bit 3:binary

Bit 4:binary

Bit 5:binary

