# letter

## Summary Stats

#instances: 20000

#features: 16

  #binary_features: 0

  #integer_features: 0

  #float_features: 16

Endpoint type: integer

#Classes: 26

Imbalance metric: 3.490919999999998e-05

## Feature Types

 x-box:continous

y-box:continous

width:continous

high:continous

onpix:continous

x-bar:continous

y-bar:continous

x2bar:continous

y2bar:continous

xybar:continous

x2ybr:continous

xy2br:continous

x-ege:continous

xegvy:continous

y-ege:continous

yegvx:continous

