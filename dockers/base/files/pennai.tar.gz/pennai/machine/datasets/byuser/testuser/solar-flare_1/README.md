# solar-flare_1

## Summary Stats

#instances: 315

#features: 12

  #binary_features: 1

  #integer_features: 11

  #float_features: 0

Endpoint type: integer

#Classes: 5

Imbalance metric: 0.03232552280171328

## Feature Types

 largest_spot_size:discrete

spot_distribution:discrete

Activity:binary

Evolution:discrete

Previous_24_hour_flare_activity_code:binary

Historically-complex:binary

Did_region_become_historically_complex:binary

Area:binary

Area_of_the_largest_spot:binary

C-class_flares_production_by_this_region:discrete

M-class_flares_production_by_this_region:discrete

X-class_flares_production_by_this_region:binary

