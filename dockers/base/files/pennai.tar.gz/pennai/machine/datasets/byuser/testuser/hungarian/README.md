# hungarian

## Summary Stats

#instances: 294

#features: 13

  #binary_features: 2

  #integer_features: 9

  #float_features: 2

Endpoint type: binary

#Classes: 2

Imbalance metric: 0.07779166088203991

## Feature Types

 age:continous

sex:binary

cp:discrete

trestbps:discrete

chol:discrete

fbs:discrete

restecg:discrete

thalach:discrete

exang:discrete

oldpeak:continous

slope:discrete

ca:binary

thal:discrete

