# biomed

## Summary Stats

#instances: 209

#features: 8

  #binary_features: 0

  #integer_features: 3

  #float_features: 5

Endpoint type: binary

#Classes: 2

Imbalance metric: 0.07969139900643302

## Feature Types

 Observation_number:discrete

Hospital_identification_number_for_blood_sample:continous

Age_of_patient:continous

Date_that_blood_sample_was_taken:continous

ml:continous

m2:discrete

m3:continous

m4:discrete

