# vowel

## Summary Stats

#instances: 990

#features: 13

  #binary_features: 2

  #integer_features: 1

  #float_features: 10

Endpoint type: integer

#Classes: 11

Imbalance metric: 0.0

## Feature Types

 Train or Test:binary

Speaker Number:discrete

Sex:binary

Feature 0:continous

Feature 1:continous

Feature 2:continous

Feature 3:continous

Feature 4:continous

Feature 5:continous

Feature 6:continous

Feature 7:continous

Feature 8:continous

Feature 9:continous

