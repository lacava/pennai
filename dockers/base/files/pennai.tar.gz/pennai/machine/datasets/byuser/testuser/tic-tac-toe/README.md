# tic-tac-toe

## Summary Stats

#instances: 958

#features: 9

  #binary_features: 0

  #integer_features: 9

  #float_features: 0

Endpoint type: binary

#Classes: 2

Imbalance metric: 0.09418107487327897

## Feature Types

 t1:discrete

t2:discrete

t3:discrete

t4:discrete

t5:discrete

t6:discrete

t7:discrete

t8:discrete

t9:discrete

