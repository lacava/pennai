# breast

## Summary Stats

#instances: 699

#features: 10

  #binary_features: 0

  #integer_features: 1

  #float_features: 9

Endpoint type: binary

#Classes: 2

Imbalance metric: 0.09637516091862275

## Feature Types

 Sample code number:continous

Clump Thickness:continous

Uniformity of Cell Size:continous

Uniformity of Cell Shape:continous

Marginal Adhesion:continous

Single Epithelial Cell Size:continous

Bare Nuclei:discrete

Bland Chromatin:continous

Normal Nucleoli:continous

Mitoses:continous

