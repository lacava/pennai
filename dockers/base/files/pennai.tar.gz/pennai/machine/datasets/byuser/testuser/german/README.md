# german

## Summary Stats

#instances: 1000

#features: 20

  #binary_features: 2

  #integer_features: 11

  #float_features: 7

Endpoint type: binary

#Classes: 2

Imbalance metric: 0.15999999999999998

## Feature Types

 Status:discrete

Duration:continous

Credit-history:discrete

Purpose:discrete

Credit:continous

Savings-account:discrete

Employment:discrete

Installment-rate:continous

Personal-status:discrete

Debtors:discrete

Residence-time:continous

Property:discrete

Age:continous

Installments:discrete

Housing:discrete

Existing-credits:continous

Job:discrete

Liable-people:continous

Telephone:binary

Foreign:binary

