# pendigits

## Summary Stats

#instances: 10992

#features: 16

  #binary_features: 0

  #integer_features: 0

  #float_features: 16

Endpoint type: integer

#Classes: 10

Imbalance metric: 0.0001780697519917151

## Feature Types

 input1:continous

input2:continous

input3:continous

input4:continous

input5:continous

input6:continous

input7:continous

input8:continous

input9:continous

input10:continous

input11:continous

input12:continous

input13:continous

input14:continous

input15:continous

input16:continous

