# liver-disorder

## Summary Stats

#instances: 345

#features: 6

  #binary_features: 0

  #integer_features: 0

  #float_features: 6

Endpoint type: binary

#Classes: 2

Imbalance metric: 0.025414828817475334

## Feature Types

 mean-corpuscular-vol:continous

alkaline-phosphotase:continous

alamine-aminotransferase:continous

aspartate-aminotransferase:continous

gamma-glutamyl-transpeptidase:continous

num-half-pint-equivalents:continous

