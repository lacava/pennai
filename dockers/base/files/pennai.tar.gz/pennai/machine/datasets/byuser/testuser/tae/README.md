# tae

## Summary Stats

#instances: 151

#features: 5

  #binary_features: 0

  #integer_features: 2

  #float_features: 3

Endpoint type: integer

#Classes: 3

Imbalance metric: 0.0003070040787684745

## Feature Types

 Whether_of_not_the_TA_is_a_native_English_speaker:binary

Course_instructor:continous

Course:continous

Summer_or_regular_semester:binary

Class_size:continous

