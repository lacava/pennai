# dermatology

## Summary Stats

#instances: 366

#features: 34

  #binary_features: 1

  #integer_features: 33

  #float_features: 0

Endpoint type: integer

#Classes: 6

Imbalance metric: 0.04145838932186687

## Feature Types

 erythema:discrete

scaling:discrete

definite_borders:discrete

itching:discrete

koebner_phenomenon:discrete

polygonal_papules:discrete

follicular_papules:discrete

oral_mucosal_involvement:discrete

knee_and_elbow_involvement:discrete

scalp_involvement:discrete

family_history:binary

melanin_incontinence:discrete

eosinophils_in_the_infiltrate:discrete

PNL_infiltrate:discrete

fibrosis_of_the_papillary_dermis:discrete

exocytosis:discrete

acanthosis:discrete

hyperkeratosis:discrete

parakeratosis:discrete

clubbing_of_the_rete_ridges:discrete

elongation_of_the_rete_ridges:discrete

thinning_of_the_suprapapillary_epidermis:discrete

spongiform_pustule:discrete

munro_microabcess:discrete

focal_hypergranulosis:discrete

disappearance_of_the_granular_layer:discrete

vacuolisation_and_damage_of_basal_layer:discrete

spongiosis:discrete

saw-tooth_appearance_of_retes:discrete

follicular_horn_plug:discrete

perifollicular_parakeratosis:discrete

inflammatory_monoluclear_inflitrate:discrete

band-like_infiltrate:discrete

Age:discrete

