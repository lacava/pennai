# cmc

## Summary Stats

#instances: 1473

#features: 9

  #binary_features: 3

  #integer_features: 4

  #float_features: 2

Endpoint type: integer

#Classes: 3

Imbalance metric: 0.03070060823264104

## Feature Types

 Wifes_age:continous

Wifes_education:discrete

Husbands_education:discrete

Number_of_children_ever_born:continous

Wifes_religion:binary

Wifes_now_working?:binary

Husbands_occupation:discrete

Standard-of-living_index:discrete

Media_exposure:binary

