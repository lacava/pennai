# bupa

## Summary Stats

#instances: 345

#features: 6

  #binary_features: 0

  #integer_features: 0

  #float_features: 6

Endpoint type: binary

#Classes: 2

Imbalance metric: 0.025414828817475334

## Feature Types

 Mcv:continous

Alkphos:continous

Sgpt:continous

Sgot:continous

Gammagt:continous

Drinks:continous

