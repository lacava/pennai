# pima

## Summary Stats

#instances: 768

#features: 8

  #binary_features: 0

  #integer_features: 0

  #float_features: 8

Endpoint type: binary

#Classes: 2

Imbalance metric: 0.09125434027777776

## Feature Types

 Pregnant:continous

plasma glucose:continous

Diastolic blood pressure:continous

Triceps skin fold thickness:continous

2-Hour serum insulin:continous

Body mass index:continous

Diabetes pedigree function:continous

Age:continous

