# mfeat-karhunen

## Summary Stats

#instances: 2000

#features: 64

  #binary_features: 0

  #integer_features: 0

  #float_features: 64

Endpoint type: integer

#Classes: 10

Imbalance metric: 0.0

## Feature Types

 att1:continous

att2:continous

att3:continous

att4:continous

att5:continous

att6:continous

att7:continous

att8:continous

att9:continous

att10:continous

att11:continous

att12:continous

att13:continous

att14:continous

att15:continous

att16:continous

att17:continous

att18:continous

att19:continous

att20:continous

att21:continous

att22:continous

att23:continous

att24:continous

att25:continous

att26:continous

att27:continous

att28:continous

att29:continous

att30:continous

att31:continous

att32:continous

att33:continous

att34:continous

att35:continous

att36:continous

att37:continous

att38:continous

att39:continous

att40:continous

att41:continous

att42:continous

att43:continous

att44:continous

att45:continous

att46:continous

att47:continous

att48:continous

att49:continous

att50:continous

att51:continous

att52:continous

att53:continous

att54:continous

att55:continous

att56:continous

att57:continous

att58:continous

att59:continous

att60:continous

att61:continous

att62:continous

att63:continous

att64:continous

