# wine-recognition

## Summary Stats

#instances: 178

#features: 13

  #binary_features: 0

  #integer_features: 2

  #float_features: 11

Endpoint type: integer

#Classes: 3

Imbalance metric: 0.012529983587930811

## Feature Types

 1:continous

2:continous

3:continous

4:continous

5:discrete

6:continous

7:continous

8:continous

9:continous

10:continous

11:continous

12:continous

13:discrete

