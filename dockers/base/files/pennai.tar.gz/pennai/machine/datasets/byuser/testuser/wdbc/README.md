# wdbc

## Summary Stats

#instances: 569

#features: 30

  #binary_features: 0

  #integer_features: 0

  #float_features: 30

Endpoint type: binary

#Classes: 2

Imbalance metric: 0.06493987849061501

## Feature Types

 Radius1:continous

Texture1:continous

Perimeter1:continous

Area1:continous

Smoothness1:continous

Compactness1:continous

Concavity1:continous

Concave_points1:continous

Symmetry1:continous

Fractal_dimension1:continous

Radius2:continous

Texture2:continous

Perimeter2:continous

Area2:continous

Smoothness2:continous

Compactness2:continous

Concavity2:continous

Concave_points2:continous

Symmetry2:continous

Fractal_dimension2:continous

Radius3:continous

Texture3:continous

Perimeter3:continous

Area3:continous

Smoothness3:continous

Compactness3:continous

Concavity3:continous

Concave_points3:continous

Symmetry3:continous

Fractal_dimension3:continous

