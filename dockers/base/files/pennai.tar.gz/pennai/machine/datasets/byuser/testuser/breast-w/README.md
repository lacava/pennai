# breast-w

## Summary Stats

#instances: 699

#features: 9

  #binary_features: 0

  #integer_features: 1

  #float_features: 8

Endpoint type: binary

#Classes: 2

Imbalance metric: 0.09637516091862275

## Feature Types

 Clump_Thickness:continous

Cell_Size_Uniformity:continous

Cell_Shape_Uniformity:continous

Marginal_Adhesion:continous

Single_Epi_Cell_Size:continous

Bare_Nuclei:discrete

Bland_Chromatin:continous

Normal_Nucleoli:continous

Mitoses:continous

