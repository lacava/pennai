# irish

## Summary Stats

#instances: 500

#features: 5

  #binary_features: 1

  #integer_features: 3

  #float_features: 1

Endpoint type: binary

#Classes: 2

Imbalance metric: 0.01254400000000001

## Feature Types

 Sex:binary

DVRT:continous

Educational_level:discrete

Prestige_score:discrete

Type_school:discrete

