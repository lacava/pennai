# xd6

## Summary Stats

#instances: 973

#features: 9

  #binary_features: 9

  #integer_features: 0

  #float_features: 0

Endpoint type: binary

#Classes: 2

Imbalance metric: 0.11433155633766365

## Feature Types

 Attribute 1:binary

Attribute 2:binary

Attribute 3:binary

Attribute 4:binary

Attribute 5:binary

Attribute 6:binary

Attribute 7:binary

Attribute 8:binary

Attribute 9:binary

