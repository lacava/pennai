# krkopt

## Summary Stats

#instances: 28056

#features: 6

  #binary_features: 0

  #integer_features: 6

  #float_features: 0

Endpoint type: integer

#Classes: 18

Imbalance metric: 0.0516687671160113

## Feature Types

 white-king-file:discrete

whike-king-rank:discrete

white-rook-file:discrete

whike-rook-rank:discrete

black-king-file:discrete

black-king-rank:discrete

