// Fails after 10 minutes
setTimeout(() => {
  process.exit(1);
}, 600000);
